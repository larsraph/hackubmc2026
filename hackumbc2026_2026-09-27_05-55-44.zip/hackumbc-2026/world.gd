extends Node2D

func _on_area_2d_area_entered(area: Area2D) -> void:
	$AnimatedSprite2D.pla()

func _on_area_2d_area_entered_2(area: Area2D) -> void:
	var starting_pos = $Sword/Camera2D.global_position
	$Sword/Camera2D.reparent($Marker2D)
	$Sword/Camera2D.position = starting_pos - $Marker2D.position
