extends RigidBody2D

@export var max_rot = 4 * PI
@export var override: Timer
@export var dash_speed: float

var ccw: bool = false

func _physics_process(delta: float) -> void:
	var mouse = get_global_mouse_position()
	var dir = global_position.direction_to(mouse)
	var target_angle = dir.angle()
	var delta_angle = wrapf(target_angle - self.rotation, -PI, PI)
	self.angular_velocity = clamp(delta_angle * (1/delta), -max_rot, max_rot)

func _input(event: InputEvent) -> void:
	if override.is_stopped():
		if get_contact_count() != 0:
			if event.is_action_pressed("spin_cw"):
				var mouse = get_global_mouse_position()
				var dir = global_position.direction_to(mouse)
				self.linear_velocity += dir * dash_speed
				override.start()
				self.physics_material_override.friction = 0


func _on_override_timeout() -> void:
	self.physics_material_override.friction = 200
